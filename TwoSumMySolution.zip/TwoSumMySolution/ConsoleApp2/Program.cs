﻿/******************************************************************************

                            Online C# Compiler.
                Code, Compile, Run and Debug C# program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

using System;
using System.IO;
class HelloWorld
{
    static void Main()
    {
        int[] a = new int[] { 2, 5, 5, 10 };
        int[] output = TwoSum(a, 10);
        for (int i = 0; i < output.Length; i++)
        {
            Console.WriteLine(output[i]);
        }
    }
    public static int[] TwoSum(int[] nums, int target)
    {
        int[] numBackup = nums.Clone() as int[];

        QuickSort(nums, 0, nums.Length - 1);

        int firstNum = 0, secondNum = 0;

        for (int i = 0, j = nums.Length - 1; i < j;)
        {
            int first = nums[i];
            int second = nums[j];

            if (first + second > target)
            {
                j--;
            }
            else if (first + second < target)
            {
                i++;
            }
            else
            {
                firstNum = first;
                secondNum = second;
                break;
            }

        }

        int[] op = new int[2];
        
        for(int j=0; j<nums.Length; j++)
        {
            if(numBackup[j] == firstNum && op[0] == 0)
            {
                op[0] = j;
                continue;
            }

            if (numBackup[j] == secondNum && op[1] == 0)
            {
                op[1] = j;
            }
        }
        return op;
    }

    public static void QuickSort(int[] a, int left, int right)
    {
        int l = left, r = right;
        if (left >= right)
        {
            return;
        }
        int pivot = left;
        while (left < right)
        {
            if (a[left] > a[right])
            {
                int temp = a[left];
                a[left] = a[right];
                a[right] = temp;
            }
            else
            {
                a[pivot] = a[left];

            }

            pivot++;
            left++;
        }

        QuickSort(a, l, pivot - 1);
        QuickSort(a, pivot + 1, r);
    }
}