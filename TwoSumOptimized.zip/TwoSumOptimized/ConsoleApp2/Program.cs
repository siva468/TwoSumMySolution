﻿/******************************************************************************

                            Online C# Compiler.
                Code, Compile, Run and Debug C# program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
class HelloWorld
{
    static void Main()
    {
        int[] a = { 2, 10, 5, 5 };
        int[] output = TwoSum(a, 10);
        for (int i = 0; i < output.Length; i++)
        {
            Console.WriteLine(output[i]);
        }
    }
    public static int[] TwoSum(int[] nums, int target)
    {
        var dictionary = new Dictionary<int, int>();

        for (int i = 0; i < nums.Length; i++)
        {
            if (dictionary.ContainsKey(target - nums[i]))
            {
                return new[] {dictionary[target - nums[i]], i};
            }
            dictionary.TryAdd(nums[i], i);
        }

        return new[] {0, 0};
    }
    
}